<?php


namespace Includes\Controllers\Admin;


use Includes\baseClasses\MNBase;

class HomeController extends MNBase
{

}